import React from 'react';

function GemDisplay({ money = 0 }) {
  return (
    <div className="gem-display" style={{textAlign:'center',margin:'1rem 0',fontWeight:'bold'}}>
      사용 금액: {money.toLocaleString()}원
    </div>
  );
}
export default GemDisplay; 