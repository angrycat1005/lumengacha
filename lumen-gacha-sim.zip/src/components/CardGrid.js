import React from 'react';

function CardGrid({ cards = [] }) {
  // 카드별 개수 집계
  const cardCount = {};
  cards.forEach(card => {
    const key = card.name + '|' + card.rarity;
    if (!cardCount[key]) cardCount[key] = { ...card, count: 0 };
    cardCount[key].count++;
  });
  const cardList = Object.values(cardCount);

  return (
    <div style={{width:'100%', background:'#e0e7ff', borderRadius:'8px', padding:'2rem'}}>
      <h3 style={{marginBottom:'1rem'}}>뽑은 카드 결과</h3>
      {cardList.length === 0 ? (
        <div style={{textAlign:'center',color:'#888'}}>뽑은 카드가 없습니다.</div>
      ) : (
        <table style={{width:'100%', borderCollapse:'collapse', background:'#fff', borderRadius:'8px', overflow:'hidden'}}>
          <thead>
            <tr style={{background:'#dbeafe'}}>
              <th style={{padding:'0.5rem', border:'1px solid #ccc'}}>카드명</th>
              <th style={{padding:'0.5rem', border:'1px solid #ccc'}}>레어도</th>
              <th style={{padding:'0.5rem', border:'1px solid #ccc'}}>개수</th>
            </tr>
          </thead>
          <tbody>
            {cardList.map((card, i) => (
              <tr key={i}>
                <td style={{padding:'0.5rem', border:'1px solid #ccc'}}>{card.name}</td>
                <td style={{padding:'0.5rem', border:'1px solid #ccc'}}>{card.rarity}</td>
                <td style={{padding:'0.5rem', border:'1px solid #ccc'}}>{card.count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
export default CardGrid; 