import React from 'react';

function ResultPanel({ history = [], onReset }) {
  const last = history[0];
  // 카드별 개수 집계
  let cardCount = {};
  if (last && last.result) {
    last.result.forEach(card => {
      const key = card.name + '|' + card.rarity;
      if (!cardCount[key]) cardCount[key] = { ...card, count: 0 };
      cardCount[key].count++;
    });
  }
  const cardList = Object.values(cardCount);

  return (
    <aside className="result-panel" style={{background:'#f5f5f5',padding:'1rem',borderRadius:'8px',minWidth:'180px'}}>
      <h2>결과/히스토리</h2>
      <div>최근 뽑기 결과:</div>
      {last ? (
        <div style={{fontSize:'0.95rem',margin:'0.5rem 0'}}>
          총 {last.result.length}장, 종류 {cardList.length}개
        </div>
      ) : <div>없음</div>}
      <div style={{marginTop:'1rem'}}>뽑기 내역: {history.length}회</div>
      <button onClick={onReset} style={{marginTop:'1rem',padding:'0.5rem 1rem',background:'#eee',border:'none',borderRadius:'6px',cursor:'pointer'}}>히스토리 초기화</button>
    </aside>
  );
}
export default ResultPanel; 