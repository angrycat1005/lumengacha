import React from 'react';

function StatisticsPanel({ money = 0, history = [] }) {
  // 레어도별 통계 계산
  const rarityCount = {};
  history.forEach(h => {
    h.result && h.result.forEach(card => {
      rarityCount[card.rarity] = (rarityCount[card.rarity] || 0) + 1;
    });
  });
  return (
    <aside className="statistics-panel" style={{background:'#f5f5f5',padding:'1rem',borderRadius:'8px',minWidth:'180px'}}>
      <h2>통계/목표</h2>
      <div>누적 금액: {money.toLocaleString()}원</div>
      <div>총 뽑기: {history.length}회</div>
      <div style={{marginTop:'1rem'}}>레어도별 통계:</div>
      <ul>
        {Object.keys(rarityCount).length === 0 && <li>-</li>}
        {Object.entries(rarityCount).map(([rarity, count]) => (
          <li key={rarity}>{rarity}: {count}장</li>
        ))}
      </ul>
    </aside>
  );
}
export default StatisticsPanel; 