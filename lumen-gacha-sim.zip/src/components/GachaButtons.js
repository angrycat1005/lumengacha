import React from 'react';

function GachaButtons({ onGacha }) {
  return (
    <div className="gacha-buttons" style={{textAlign:'center',margin:'1rem 0'}}>
      <button onClick={() => onGacha('1pack')}>1팩 뽑기</button>
      <button onClick={() => onGacha('10pack')}>10팩 뽑기</button>
      <button onClick={() => onGacha('1box')}>1통 뽑기</button>
      <button onClick={() => onGacha('10box')}>10통 뽑기</button>
      <button onClick={() => onGacha('1carton')}>1카톤 뽑기</button>
    </div>
  );
}
export default GachaButtons; 