import React from 'react';

function CardCollection({ cards = [], onClose }) {
  // 카드별 개수 집계
  const cardCount = {};
  cards.forEach(card => {
    const key = card.name + '|' + card.rarity;
    if (!cardCount[key]) cardCount[key] = { ...card, count: 0 };
    cardCount[key].count++;
  });
  const cardList = Object.values(cardCount);

  return (
    <div style={{position:'fixed',top:0,left:0,width:'100vw',height:'100vh',background:'#0008',zIndex:1000,display:'flex',justifyContent:'center',alignItems:'center'}}>
      <div style={{background:'#fff',borderRadius:'12px',padding:'2rem',minWidth:'400px',maxHeight:'80vh',overflowY:'auto',boxShadow:'0 4px 24px #0004', position:'relative'}}>
        <h2 style={{marginBottom:'1rem'}}>내 카드 보관함</h2>
        <button onClick={onClose} style={{position:'absolute',top:'1.5rem',right:'2.5rem',background:'#eee',border:'none',borderRadius:'6px',padding:'0.3rem 1rem',cursor:'pointer'}}>닫기</button>
        {cardList.length === 0 ? (
          <div style={{textAlign:'center',color:'#888'}}>아직 뽑은 카드가 없습니다.</div>
        ) : (
          <table style={{width:'100%', borderCollapse:'collapse', background:'#fff', borderRadius:'8px', overflow:'hidden'}}>
            <thead>
              <tr style={{background:'#dbeafe'}}>
                <th style={{padding:'0.5rem', border:'1px solid #ccc'}}>카드명</th>
                <th style={{padding:'0.5rem', border:'1px solid #ccc'}}>레어도</th>
                <th style={{padding:'0.5rem', border:'1px solid #ccc'}}>개수</th>
              </tr>
            </thead>
            <tbody>
              {cardList.map((card, i) => (
                <tr key={i}>
                  <td style={{padding:'0.5rem', border:'1px solid #ccc'}}>{card.name}</td>
                  <td style={{padding:'0.5rem', border:'1px solid #ccc'}}>{card.rarity}</td>
                  <td style={{padding:'0.5rem', border:'1px solid #ccc'}}>{card.count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default CardCollection; 