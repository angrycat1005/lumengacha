import React, { useState, useEffect } from 'react';
import StatisticsPanel from './components/StatisticsPanel';
import CardGrid from './components/CardGrid';
import ResultPanel from './components/ResultPanel';
import GachaButtons from './components/GachaButtons';
import GemDisplay from './components/GemDisplay';
import CardCollection from './components/CardCollection';
import {
  drawOnePack,
  drawTenPacks,
  drawOneBox,
  drawTenBoxes,
  drawOneCarton,
  drawOnePackWithSpecial,
  getCardPoolByPackEntries
} from './utils/gachaLogic';
import './App.css';

function App() {
  const [packs, setPacks] = useState([]);
  const [selectedPackId, setSelectedPackId] = useState('');
  const [selectedPack, setSelectedPack] = useState(null);
  const [cardPool, setCardPool] = useState([]);
  const [drawResult, setDrawResult] = useState([]);
  const [money, setMoney] = useState(0);
  const [history, setHistory] = useState([]);
  const [collection, setCollection] = useState([]); // 누적 카드
  const [showCollection, setShowCollection] = useState(false);
  const [cardData, setCardData] = useState([]); // sample_pack.json 카드 데이터

  // packs.json 로딩 및 팩 선택
  useEffect(() => {
    fetch(process.env.PUBLIC_URL + '/data/packs.json')
      .then(res => res.json())
      .then(data => {
        setPacks(data);
        setSelectedPackId(data[0]?.id || '');
      });
  }, []);

  // sample_pack.json 로딩
  useEffect(() => {
    fetch(process.env.PUBLIC_URL + '/data/sample_pack.json')
      .then(res => res.json())
      .then(data => setCardData(data));
  }, []);

  useEffect(() => {
    const pack = packs.find(p => p.id === selectedPackId);
    setSelectedPack(pack || null);
    if (pack && cardData.length > 0) {
      // cardPool id+rarity 쌍 배열을 카드 객체 배열로 변환
      const cards = getCardPoolByPackEntries(pack.cardPool, cardData);
      setCardPool(cards);
    } else {
      setCardPool([]);
    }
  }, [packs, selectedPackId, cardData]);

  // 뽑기 핸들러
  const handleGacha = (type) => {
    if (!cardPool.length || !selectedPack) return;
    let result = [];
    let moneyCost = 0;
    const { pricePerPack, cardsPerPack, packsPerBox, boxesPerCarton, type: packType, cardPool: cardPoolIds } = selectedPack;
    const isSpecialPack = packType === 'special';
    const specialIds = isSpecialPack ? cardPoolIds.filter(id => id.startsWith('s')) : [];
    if (type === '1pack') {
      result = isSpecialPack
        ? drawOnePackWithSpecial(cardPool, specialIds)
        : drawOnePack(cardPool);
      moneyCost = pricePerPack;
    } else if (type === '10pack') {
      result = [];
      for (let i = 0; i < 10; i++) {
        result = result.concat(
          isSpecialPack
            ? drawOnePackWithSpecial(cardPool, specialIds)
            : drawOnePack(cardPool)
        );
      }
      moneyCost = pricePerPack * 10;
    } else if (type === '1box') {
      result = drawOneBox(cardPool).boxCards;
      moneyCost = pricePerPack * packsPerBox;
    } else if (type === '10box') {
      result = drawTenBoxes(cardPool);
      moneyCost = pricePerPack * packsPerBox * 10;
    } else if (type === '1carton') {
      result = drawOneCarton(cardPool);
      moneyCost = pricePerPack * packsPerBox * boxesPerCarton;
    }
    setDrawResult(result);
    setMoney(money + moneyCost);
    setHistory([{ type, result, date: new Date(), pack: selectedPack.name }, ...history]);
    setCollection([...collection, ...result]); // 누적 카드 추가
  };

  // 히스토리 초기화
  const handleResetHistory = () => {
    setHistory([]);
    setMoney(0);
    setDrawResult([]);
    setCollection([]); // 보관함도 초기화
  };

  return (
    <div className="app-container" style={{display:'flex',flexDirection:'column',minHeight:'100vh'}}>
      <header className="app-header" style={{textAlign:'center',fontSize:'2rem',padding:'1rem',background:'#222',color:'#fff',position:'relative'}}>
        루멘콘덴서 카드팩 뽑기 시뮬레이터
        <div style={{position:'absolute',left:'2rem',top:'1.2rem'}}>
          <select value={selectedPackId} onChange={e => setSelectedPackId(e.target.value)} style={{fontSize:'1rem',padding:'0.3rem 1rem',borderRadius:'6px'}}>
            {packs.map(pack => (
              <option key={pack.id} value={pack.id}>{pack.name}</option>
            ))}
          </select>
        </div>
        <button onClick={()=>setShowCollection(true)} style={{position:'absolute',right:'2rem',top:'1.2rem',padding:'0.5rem 1rem',background:'#e0e7ff',border:'none',borderRadius:'6px',cursor:'pointer',fontWeight:'bold'}}>내 카드 보관함</button>
      </header>
      <div className="main-layout" style={{display:'flex',flex:1,padding:'1rem',gap:'1rem'}}>
        <StatisticsPanel money={money} history={history} />
        <div style={{flex:1,display:'flex',justifyContent:'center',alignItems:'center'}}>
          <CardGrid cards={drawResult} />
        </div>
        <ResultPanel history={history} onReset={handleResetHistory} />
      </div>
      <GachaButtons onGacha={handleGacha} />
      <GemDisplay money={money} />
      {showCollection && <CardCollection cards={collection} onClose={()=>setShowCollection(false)} />}
    </div>
  );
}

export default App;
