// packs.json의 cardPool [{id, rarity}] 배열을 sample_pack.json의 카드 객체 배열로 변환
export function getCardPoolByPackEntries(entries, cardData) {
  return entries
    .map(entry => {
      const card = cardData.find(card => card.id === entry.id);
      if (!card) return null;
      return { ...card, rarity: entry.rarity };
    })
    .filter(Boolean);
}

// 카드 1장 뽑기 (확률 기반)
export function drawOneCard(cardPool) {
  const rand = Math.random();
  let acc = 0;
  for (const card of cardPool) {
    acc += card.probability;
    if (rand < acc) return card;
  }
  // 확률 합이 1이 안될 경우 대비
  return cardPool[cardPool.length - 1];
}

// 레어도별 카드 분리
function splitByRarity(cardPool) {
  const byRarity = { N: [], AN: [], SR: [], EX: [], AEX: [], SAEX: [], SP: [] };
  cardPool.forEach(card => {
    if (byRarity[card.rarity]) byRarity[card.rarity].push(card);
  });
  return byRarity;
}

function pickRandom(arr, n = 1) {
  // arr에서 n개 랜덤 추출(중복 없음)
  const copy = [...arr];
  const result = [];
  for (let i = 0; i < n && copy.length > 0; i++) {
    const idx = Math.floor(Math.random() * copy.length);
    result.push(copy.splice(idx, 1)[0]);
  }
  return n === 1 ? result[0] : result;
}

// 1팩(4장) 뽑기: SR 1장 보장, 나머지 N/AN
export function drawOnePack(cardPool, isCarton = false) {
  const byRarity = splitByRarity(cardPool);
  const result = [];
  // SR 보장
  if (byRarity.SR.length > 0) {
    result.push(pickRandom(byRarity.SR));
  }
  // 나머지 3장은 N/AN에서 확률로
  const nAnPool = [...byRarity.N, ...byRarity.AN];
  for (let i = 0; i < 3; i++) {
    if (nAnPool.length === 0) break;
    result.push(pickRandom(nAnPool));
  }
  // SAEX, SP 극악 확률 등장 (예: 0.0005) - 카톤에서는 제외
  if (!isCarton) {
    if (byRarity.SAEX.length > 0 && Math.random() < 0.0005) {
      result.push(pickRandom(byRarity.SAEX));
    }
    if (byRarity.SP.length > 0 && Math.random() < 0.0005) {
      result.push(pickRandom(byRarity.SP));
    }
  }
  return result;
}

// 스페셜팩: 특정 id 카드가 반드시 1장 포함되도록 보장
export function drawOnePackWithSpecial(cardPool, specialIds = []) {
  const result = drawOnePack(cardPool);
  specialIds.forEach(specialId => {
    const hasSpecial = result.some(card => card.id === specialId);
    if (!hasSpecial) {
      const idx = Math.floor(Math.random() * result.length);
      const specialCard = cardPool.find(card => card.id === specialId);
      if (specialCard) result[idx] = specialCard;
    }
  });
  return result;
}

// 1통(30팩) 뽑기: EX 3장, AEX 1장, (AEX가 뜨면 SP/SAEX 불가), SP/SAEX는 카톤에서만 보장
export function drawOneBox(cardPool, spSaexQuota = { SP: 0, SAEX: 0 }, isCarton = false) {
  const byRarity = splitByRarity(cardPool);
  let packs = [];
  // 1. AEX 등장 확률 (10%)
  let aexGiven = false;
  if (byRarity.AEX.length > 0 && Math.random() < 0.1) { // 10% 확률
    aexGiven = true;
  }
  // 2. EX 보장 (AEX가 있으면 2장, 없으면 3장)
  let exCount = 0;
  if (byRarity.EX.length > 0) {
    exCount = aexGiven ? 2 : 3;
  }
  // 3. 30팩 생성 (SR 보장)
  for (let i = 0; i < 30; i++) {
    packs.push(drawOnePack(cardPool, isCarton));
  }
  // 4. 보장 카드 치환
  let boxCards = packs.flat(); // 120장
  // 치환할 인덱스 랜덤 추출
  function getRandomIndices(total, count) {
    const arr = Array.from({length: total}, (_, i) => i);
    const result = [];
    for (let i = 0; i < count && arr.length > 0; i++) {
      const idx = Math.floor(Math.random() * arr.length);
      result.push(arr.splice(idx, 1)[0]);
    }
    return result;
  }
  // AEX 치환
  if (aexGiven) {
    const idx = getRandomIndices(boxCards.length, 1)[0];
    boxCards[idx] = pickRandom(byRarity.AEX);
  }
  // EX 치환
  if (exCount > 0) {
    const exIdxs = getRandomIndices(boxCards.length, exCount);
    exIdxs.forEach(idx => {
      boxCards[idx] = pickRandom(byRarity.EX);
    });
  }
  // SP/SAEX는 카톤에서만 할당
  return { boxCards, aexGiven };
}

// 1카톤(40통) 뽑기: SP+SAEX 합 3장 보장, SP/SAEX 상호배제, 각 통별로 위 규칙 적용
export function drawOneCarton(cardPool) {
  const byRarity = splitByRarity(cardPool);
  let cartonCards = [];
  // 1. 40통 생성 (각 통의 boxCards, aexGiven 여부 저장)
  let boxes = [];
  for (let i = 0; i < 40; i++) {
    boxes.push(drawOneBox(cardPool, undefined, true));
  }
  // 2. AEX가 없는 통만 추출
  const boxesWithoutAEX = boxes.map((box, idx) => ({...box, idx})).filter(box => !box.aexGiven);
  // 3. SP/SAEX 3장 보장 (합이 3장, 상호배제, 랜덤 분배)
  let spCount = 0, saexCount = 0;
  if (byRarity.SP.length > 0 && byRarity.SAEX.length > 0) {
    // SP와 SAEX를 랜덤하게 합 3장 배분
    const arr = [];
    for (let i = 0; i < 3; i++) arr.push(Math.random() < 0.5 ? 'SP' : 'SAEX');
    spCount = arr.filter(x => x === 'SP').length;
    saexCount = 3 - spCount;
  } else if (byRarity.SP.length > 0) {
    spCount = 3;
  } else if (byRarity.SAEX.length > 0) {
    saexCount = 3;
  }
  // 4. SP/SAEX를 AEX 없는 통에 분배 (통이 3개 미만이면 중복 허용, 반드시 치환)
  let spLeft = spCount, saexLeft = saexCount;
  let candidateBoxes = [...boxesWithoutAEX];
  if (candidateBoxes.length === 0) {
    candidateBoxes = boxes.map((box, idx) => ({...box, idx}));
  }
  let insertIdx = 0;
  while (spLeft > 0) {
    const box = candidateBoxes[insertIdx % candidateBoxes.length];
    // 치환 인덱스 선정
    const idx = Math.floor(Math.random() * boxes[box.idx].boxCards.length);
    boxes[box.idx].boxCards[idx] = pickRandom(byRarity.SP);
    spLeft--;
    insertIdx++;
  }
  insertIdx = 0;
  while (saexLeft > 0) {
    const box = candidateBoxes[insertIdx % candidateBoxes.length];
    const idx = Math.floor(Math.random() * boxes[box.idx].boxCards.length);
    boxes[box.idx].boxCards[idx] = pickRandom(byRarity.SAEX);
    saexLeft--;
    insertIdx++;
  }
  // 5. 모든 통의 카드 합치기
  for (let i = 0; i < 40; i++) {
    cartonCards = cartonCards.concat(boxes[i].boxCards);
  }
  return cartonCards;
}

// 10팩, 10통 등은 기존대로 반복 호출
export function drawTenPacks(cardPool) {
  let result = [];
  for (let i = 0; i < 10; i++) {
    result = result.concat(drawOnePack(cardPool));
  }
  return result;
}
export function drawTenBoxes(cardPool) {
  let result = [];
  for (let i = 0; i < 10; i++) {
    result = result.concat(drawOneBox(cardPool).boxCards);
  }
  return result;
} 